from django.shortcuts import render, redirect
from django.contrib import messages
from django.core.mail import send_mail
from django.conf import settings
from .models import Club, Deporte, Horario, Instalacion, Testimonio

def landing_view(request):
    """
    Vista principal de la landing page del club deportivo
    """
    context = {
        'club': Club.objects.first(),  # Información general del club
        'hero': {
            'titulo': 'Tu lugar para el deporte y la comunidad',
            'descripcion': 'Únete al Club Atletico Racing y descubre un espacio donde el deporte, la amistad y los valores se encuentran.',
            'imagen': None  # Se puede agregar desde el admin
        },
        'sobre_nosotros': {
            'subtitulo': 'Somos más que un club deportivo, somos una familia unida por la pasión del deporte',
            'items': [
                {
                    'icono': 'fas fa-heart',
                    'titulo': 'Nuestra Historia',
                    'descripcion': 'Fundado en 2008, el Club Atletico Racing nació del sueño de crear un espacio donde los niños y jóvenes de nuestra comunidad pudieran desarrollarse a través del deporte.'
                },
                {
                    'icono': 'fas fa-users',
                    'titulo': 'Nuestra Misión',
                    'descripcion': 'Promover valores como el trabajo en equipo, la disciplina y el respeto, mientras brindamos un ambiente seguro y divertido para practicar deporte.'
                },
                {
                    'icono': 'fas fa-trophy',
                    'titulo': 'Nuestros Logros',
                    'descripcion': 'Más de 300 socios activos, múltiples campeonatos locales y, lo más importante, cientos de niños y jóvenes formados en valores deportivos.'
                }
            ]
        },
        'deportes': Deporte.objects.filter(activo=True),
        'horarios': Horario.objects.all().order_by('hora_inicio'),
        'instalaciones': Instalacion.objects.filter(activo=True),
        'testimonios': Testimonio.objects.filter(activo=True)[:3],
    }
    
    return render(request, 'landing.html', context)

def contacto_view(request):
    """
    Vista para procesar el formulario de contacto
    """
    if request.method == 'POST':
        nombre = request.POST.get('nombre')
        telefono = request.POST.get('telefono')
        email = request.POST.get('email')
        deporte = request.POST.get('deporte')
        edad = request.POST.get('edad')
        mensaje = request.POST.get('mensaje')
        
        # Aquí puedes procesar los datos como necesites
        # Por ejemplo, guardar en base de datos o enviar email
        
        try:
            # Enviar email de notificación
            send_mail(
                subject=f'Nueva consulta de {nombre}',
                message=f'''
                Nueva consulta recibida:
                
                Nombre: {nombre}
                Teléfono: {telefono}
                Email: {email}
                Deporte de interés: {deporte}
                Edad: {edad}
                Mensaje: {mensaje}
                ''',
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=[settings.CONTACT_EMAIL],
                fail_silently=False,
            )
            
            messages.success(request, '¡Gracias por tu consulta! Nos pondremos en contacto contigo pronto.')
            
        except Exception as e:
            messages.error(request, 'Hubo un error al enviar tu consulta. Por favor, intenta nuevamente.')
        
        return redirect('landing')
    
    return redirect('landing')
