from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator

class Club(models.Model):
    """Modelo para la información general del club"""
    nombre = models.CharField(max_length=100, default="Club Atletico Racing")
    eslogan = models.CharField(max_length=100, default="Deporte y Comunidad")
    anos_funcionamiento = models.IntegerField(default=15)
    descripcion_footer = models.TextField(default="Más de 15 años formando campeones y construyendo comunidad a través del deporte.")
    
    # Información de contacto
    direccion = models.CharField(max_length=200, default="Av. Deportes 1234, Ciudad")
    telefono = models.CharField(max_length=20, default="+54 11 1234-5678")
    email = models.EmailField(default="info@clubracing.com")
    horarios = models.CharField(max_length=100, default="Lun-Sáb: 15:00-21:00")
    
    # Redes sociales
    facebook = models.URLField(blank=True, null=True)
    instagram = models.URLField(blank=True, null=True)
    twitter = models.URLField(blank=True, null=True)
    
    # Timestamps
    creado = models.DateTimeField(auto_now_add=True)
    actualizado = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "Club"
        verbose_name_plural = "Club"
    
    def __str__(self):
        return self.nombre

class Categoria(models.Model):
    """Modelo para las categorías de edad de los deportes"""
    nombre = models.CharField(max_length=50)
    edad_minima = models.IntegerField()
    edad_maxima = models.IntegerField()
    activo = models.BooleanField(default=True)
    
    class Meta:
        verbose_name = "Categoría"
        verbose_name_plural = "Categorías"
    
    def __str__(self):
        return self.nombre

class Deporte(models.Model):
    """Modelo para los deportes que ofrece el club"""
    COLORES_CHOICES = [
        ('#0ea5e9', 'Celeste'),
        ('#f97316', 'Naranja'),
        ('#10b981', 'Verde'),
        ('#8b5cf6', 'Púrpura'),
        ('#ef4444', 'Rojo'),
        ('#3b82f6', 'Azul'),
    ]
    
    ICONOS_CHOICES = [
        ('fas fa-futbol', 'Fútbol'),
        ('fas fa-basketball-ball', 'Básquet'),
        ('fas fa-volleyball-ball', 'Vóley'),
        ('fas fa-hockey-puck', 'Hockey'),
        ('fas fa-running', 'Atletismo'),
        ('fas fa-swimmer', 'Natación'),
    ]
    
    nombre = models.CharField(max_length=50)
    descripcion = models.TextField()
    icono = models.CharField(max_length=50, choices=ICONOS_CHOICES, default='fas fa-futbol')
    color = models.CharField(max_length=7, choices=COLORES_CHOICES, default='#0ea5e9')
    categorias = models.ManyToManyField(Categoria, blank=True)
    activo = models.BooleanField(default=True)
    orden = models.IntegerField(default=0)
    
    # Timestamps
    creado = models.DateTimeField(auto_now_add=True)
    actualizado = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "Deporte"
        verbose_name_plural = "Deportes"
        ordering = ['orden', 'nombre']
    
    def __str__(self):
        return self.nombre

class Horario(models.Model):
    """Modelo para los horarios de actividades"""
    hora_inicio = models.TimeField()
    hora_fin = models.TimeField()
    lunes = models.CharField(max_length=100, blank=True, null=True)
    martes = models.CharField(max_length=100, blank=True, null=True)
    miercoles = models.CharField(max_length=100, blank=True, null=True)
    jueves = models.CharField(max_length=100, blank=True, null=True)
    viernes = models.CharField(max_length=100, blank=True, null=True)
    sabado = models.CharField(max_length=100, blank=True, null=True)
    domingo = models.CharField(max_length=100, blank=True, null=True)
    
    activo = models.BooleanField(default=True)
    
    # Timestamps
    creado = models.DateTimeField(auto_now_add=True)
    actualizado = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "Horario"
        verbose_name_plural = "Horarios"
        ordering = ['hora_inicio']
    
    def __str__(self):
        return f"{self.hora_inicio.strftime('%H:%M')} - {self.hora_fin.strftime('%H:%M')}"

class Instalacion(models.Model):
    """Modelo para las instalaciones del club"""
    nombre = models.CharField(max_length=100)
    descripcion = models.TextField()
    imagen = models.ImageField(upload_to='instalaciones/', blank=True, null=True)
    activo = models.BooleanField(default=True)
    orden = models.IntegerField(default=0)
    
    # Timestamps
    creado = models.DateTimeField(auto_now_add=True)
    actualizado = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "Instalación"
        verbose_name_plural = "Instalaciones"
        ordering = ['orden', 'nombre']
    
    def __str__(self):
        return self.nombre

class Testimonio(models.Model):
    """Modelo para los testimonios de socios"""
    nombre = models.CharField(max_length=100)
    descripcion = models.CharField(max_length=100)  # Ej: "Madre de socio - Fútbol Infantil"
    comentario = models.TextField()
    calificacion = models.IntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)],
        default=5
    )
    foto = models.ImageField(upload_to='testimonios/', blank=True, null=True)
    iniciales = models.CharField(max_length=3, help_text="Iniciales para mostrar si no hay foto")
    activo = models.BooleanField(default=True)
    orden = models.IntegerField(default=0)
    
    # Timestamps
    creado = models.DateTimeField(auto_now_add=True)
    actualizado = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "Testimonio"
        verbose_name_plural = "Testimonios"
        ordering = ['orden', '-creado']
    
    def __str__(self):
        return f"{self.nombre} - {self.calificacion} estrellas"

class Consulta(models.Model):
    """Modelo para guardar las consultas del formulario de contacto"""
    nombre = models.CharField(max_length=100)
    telefono = models.CharField(max_length=20)
    email = models.EmailField()
    deporte = models.ForeignKey(Deporte, on_delete=models.SET_NULL, null=True, blank=True)
    edad = models.IntegerField(null=True, blank=True)
    mensaje = models.TextField()
    
    # Estado de la consulta
    ESTADOS = [
        ('pendiente', 'Pendiente'),
        ('contactado', 'Contactado'),
        ('inscrito', 'Inscrito'),
        ('descartado', 'Descartado'),
    ]
    estado = models.CharField(max_length=20, choices=ESTADOS, default='pendiente')
    
    # Timestamps
    creado = models.DateTimeField(auto_now_add=True)
    actualizado = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "Consulta"
        verbose_name_plural = "Consultas"
        ordering = ['-creado']
    
    def __str__(self):
        return f"{self.nombre} - {self.email}"
