from django.contrib import admin
from .models import Club, Deporte, Categoria, Horario, Instalacion, Testimonio, Consulta

@admin.register(Club)
class ClubAdmin(admin.ModelAdmin):
    list_display = ['nombre', 'eslogan', 'telefono', 'email']
    fieldsets = (
        ('Información General', {
            'fields': ('nombre', 'eslogan', 'anos_funcionamiento', 'descripcion_footer')
        }),
        ('Contacto', {
            'fields': ('direccion', 'telefono', 'email', 'horarios')
        }),
        ('Redes Sociales', {
            'fields': ('facebook', 'instagram', 'twitter')
        }),
    )

@admin.register(Categoria)
class CategoriaAdmin(admin.ModelAdmin):
    list_display = ['nombre', 'edad_minima', 'edad_maxima', 'activo']
    list_filter = ['activo']

@admin.register(Deporte)
class DeporteAdmin(admin.ModelAdmin):
    list_display = ['nombre', 'color', 'activo', 'orden']
    list_filter = ['activo']
    filter_horizontal = ['categorias']
    ordering = ['orden', 'nombre']

@admin.register(Horario)
class HorarioAdmin(admin.ModelAdmin):
    list_display = ['__str__', 'lunes', 'martes', 'miercoles', 'activo']
    list_filter = ['activo']

@admin.register(Instalacion)
class InstalacionAdmin(admin.ModelAdmin):
    list_display = ['nombre', 'activo', 'orden']
    list_filter = ['activo']
    ordering = ['orden', 'nombre']

@admin.register(Testimonio)
class TestimonioAdmin(admin.ModelAdmin):
    list_display = ['nombre', 'calificacion', 'activo', 'orden']
    list_filter = ['calificacion', 'activo']
    ordering = ['orden', '-creado']

@admin.register(Consulta)
class ConsultaAdmin(admin.ModelAdmin):
    list_display = ['nombre', 'email', 'deporte', 'estado', 'creado']
    list_filter = ['estado', 'deporte', 'creado']
    readonly_fields = ['creado', 'actualizado']
    ordering = ['-creado']
