import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  MapPin,
  Phone,
  Mail,
  Clock,
  Users,
  Trophy,
  Heart,
  Facebook,
  Instagram,
  Twitter,
  Calendar,
  Star,
  Eye,
  EyeOff,
  User,
} from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
;("use client")

export default function ClubRacingLanding() {
  const [showPassword, setShowPassword] = useState(false)
  const [loginData, setLoginData] = useState({ username: "", password: "" })
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-sky-100">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-sky-500 rounded-full flex items-center justify-center">
              <Trophy className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">Club Atletico Racing</h1>
              <p className="text-sm text-sky-600">Deporte y Comunidad</p>
            </div>
          </div>
          <nav className="hidden md:flex space-x-6 items-center">
            <Link href="#inicio" className="text-gray-700 hover:text-sky-600 transition-colors">
              Inicio
            </Link>
            <Link href="#nosotros" className="text-gray-700 hover:text-sky-600 transition-colors">
              Nosotros
            </Link>
            <Link href="#deportes" className="text-gray-700 hover:text-sky-600 transition-colors">
              Deportes
            </Link>
            <Link href="#horarios" className="text-gray-700 hover:text-sky-600 transition-colors">
              Horarios
            </Link>
            <Link href="#contacto" className="text-gray-700 hover:text-sky-600 transition-colors">
              Contacto
            </Link>

            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" className="border-sky-500 text-sky-600 hover:bg-sky-50 ml-4 bg-transparent">
                  <User className="h-4 w-4 mr-2" />
                  Login
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle className="text-center text-sky-600">Acceso al Sistema</DialogTitle>
                  <DialogDescription className="text-center">
                    Ingresa tus credenciales para acceder al sistema de gestión del club
                  </DialogDescription>
                </DialogHeader>

                <form className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label htmlFor="username">Usuario</Label>
                    <Input
                      id="username"
                      placeholder="Ingresa tu usuario"
                      value={loginData.username}
                      onChange={(e) => setLoginData({ ...loginData, username: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="password">Contraseña</Label>
                    <div className="relative">
                      <Input
                        id="password"
                        type={showPassword ? "text" : "password"}
                        placeholder="Ingresa tu contraseña"
                        value={loginData.password}
                        onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                      />
                      <button
                        type="button"
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="remember" className="rounded border-gray-300" />
                    <Label htmlFor="remember" className="text-sm text-gray-600">
                      Recordar sesión
                    </Label>
                  </div>

                  <Button className="w-full bg-sky-500 hover:bg-sky-600 text-white">Iniciar Sesión</Button>

                  <div className="text-center space-y-2">
                    <Link href="#" className="text-sm text-sky-600 hover:text-sky-700">
                      ¿Olvidaste tu contraseña?
                    </Link>
                    <p className="text-xs text-gray-500">Solo personal autorizado del club</p>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </nav>
          {/* Mobile menu button */}
          <div className="md:hidden">
            <Dialog>
              <DialogTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  className="border-sky-500 text-sky-600 hover:bg-sky-50 bg-transparent"
                >
                  <User className="h-4 w-4 mr-1" />
                  Login
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle className="text-center text-sky-600">Acceso al Sistema</DialogTitle>
                  <DialogDescription className="text-center">
                    Ingresa tus credenciales para acceder al sistema de gestión del club
                  </DialogDescription>
                </DialogHeader>

                <form className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label htmlFor="username-mobile">Usuario</Label>
                    <Input
                      id="username-mobile"
                      placeholder="Ingresa tu usuario"
                      value={loginData.username}
                      onChange={(e) => setLoginData({ ...loginData, username: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="password-mobile">Contraseña</Label>
                    <div className="relative">
                      <Input
                        id="password-mobile"
                        type={showPassword ? "text" : "password"}
                        placeholder="Ingresa tu contraseña"
                        value={loginData.password}
                        onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                      />
                      <button
                        type="button"
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="remember-mobile" className="rounded border-gray-300" />
                    <Label htmlFor="remember-mobile" className="text-sm text-gray-600">
                      Recordar sesión
                    </Label>
                  </div>

                  <Button className="w-full bg-sky-500 hover:bg-sky-600 text-white">Iniciar Sesión</Button>

                  <div className="text-center space-y-2">
                    <Link href="#" className="text-sm text-sky-600 hover:text-sky-700">
                      ¿Olvidaste tu contraseña?
                    </Link>
                    <p className="text-xs text-gray-500">Solo personal autorizado del club</p>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section id="inicio" className="relative bg-gradient-to-br from-sky-500 to-sky-600 text-white py-20 lg:py-32">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <Badge className="bg-white/20 text-white border-white/30 hover:bg-white/30">
                ¡Más de 15 años formando campeones!
              </Badge>
              <h1 className="text-4xl lg:text-6xl font-bold leading-tight">Tu lugar para el deporte y la comunidad</h1>
              <p className="text-xl text-sky-100 leading-relaxed">
                Únete al Club Atletico Racing y descubre un espacio donde el deporte, la amistad y los valores se
                encuentran. Ofrecemos fútbol infantil, básquet, vóley y hockey para todas las edades.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="bg-white text-sky-600 hover:bg-sky-50 font-semibold">
                  Únete Ahora
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white text-white hover:bg-white hover:text-sky-600 bg-transparent"
                >
                  Ver Actividades
                </Button>
              </div>
            </div>
            <div className="relative">
              <Image
                src="/placeholder.svg?height=500&width=600"
                alt="Niños jugando fútbol en el Club Racing"
                width={600}
                height={500}
                className="rounded-lg shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Sobre Nosotros */}
      <section id="nosotros" className="py-16 lg:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Sobre Nosotros</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Somos más que un club deportivo, somos una familia unida por la pasión del deporte
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-sky-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Heart className="h-6 w-6 text-sky-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Nuestra Historia</h3>
                  <p className="text-gray-600">
                    Fundado en 2008, el Club Atletico Racing nació del sueño de crear un espacio donde los niños y
                    jóvenes de nuestra comunidad pudieran desarrollarse a través del deporte.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-sky-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Users className="h-6 w-6 text-sky-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Nuestra Misión</h3>
                  <p className="text-gray-600">
                    Promover valores como el trabajo en equipo, la disciplina y el respeto, mientras brindamos un
                    ambiente seguro y divertido para practicar deporte.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-sky-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Trophy className="h-6 w-6 text-sky-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Nuestros Logros</h3>
                  <p className="text-gray-600">
                    Más de 300 socios activos, múltiples campeonatos locales y, lo más importante, cientos de niños y
                    jóvenes formados en valores deportivos.
                  </p>
                </div>
              </div>
            </div>

            <div className="relative">
              <Image
                src="/placeholder.svg?height=400&width=500"
                alt="Instalaciones del Club Racing"
                width={500}
                height={400}
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Nuestros Deportes */}
      <section id="deportes" className="py-16 lg:py-24">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Nuestros Deportes</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Ofrecemos una variedad de disciplinas deportivas para todas las edades y niveles
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="text-center hover:shadow-lg transition-shadow border-sky-100">
              <CardHeader>
                <div className="w-16 h-16 bg-sky-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <div className="w-8 h-8 bg-sky-500 rounded-full"></div>
                </div>
                <CardTitle className="text-sky-600">Fútbol Infantil</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-gray-600">
                  Categorías desde los 4 hasta los 16 años. Formación integral con énfasis en técnica y valores.
                </CardDescription>
                <div className="mt-4 space-y-2">
                  <Badge variant="secondary" className="text-xs">
                    4-8 años
                  </Badge>
                  <Badge variant="secondary" className="text-xs">
                    9-12 años
                  </Badge>
                  <Badge variant="secondary" className="text-xs">
                    13-16 años
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow border-sky-100">
              <CardHeader>
                <div className="w-16 h-16 bg-sky-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <div className="w-8 h-8 bg-orange-500 rounded-full"></div>
                </div>
                <CardTitle className="text-sky-600">Básquet</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-gray-600">
                  Desarrollo de habilidades motoras y trabajo en equipo. Categorías juveniles y adultas.
                </CardDescription>
                <div className="mt-4 space-y-2">
                  <Badge variant="secondary" className="text-xs">
                    10-14 años
                  </Badge>
                  <Badge variant="secondary" className="text-xs">
                    15-18 años
                  </Badge>
                  <Badge variant="secondary" className="text-xs">
                    Adultos
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow border-sky-100">
              <CardHeader>
                <div className="w-16 h-16 bg-sky-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <div className="w-8 h-8 bg-green-500 rounded-full"></div>
                </div>
                <CardTitle className="text-sky-600">Vóley</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-gray-600">
                  Deporte mixto que fomenta la coordinación y el espíritu de equipo. Todas las edades.
                </CardDescription>
                <div className="mt-4 space-y-2">
                  <Badge variant="secondary" className="text-xs">
                    12-16 años
                  </Badge>
                  <Badge variant="secondary" className="text-xs">
                    Juveniles
                  </Badge>
                  <Badge variant="secondary" className="text-xs">
                    Adultos
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow border-sky-100">
              <CardHeader>
                <div className="w-16 h-16 bg-sky-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <div className="w-8 h-8 bg-purple-500 rounded-full"></div>
                </div>
                <CardTitle className="text-sky-600">Hockey</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-gray-600">
                  Hockey sobre césped para damas y caballeros. Técnica, estrategia y diversión.
                </CardDescription>
                <div className="mt-4 space-y-2">
                  <Badge variant="secondary" className="text-xs">
                    14-18 años
                  </Badge>
                  <Badge variant="secondary" className="text-xs">
                    Juveniles
                  </Badge>
                  <Badge variant="secondary" className="text-xs">
                    Adultos
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Horarios */}
      <section id="horarios" className="py-16 lg:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Horarios de Actividades</h2>
            <p className="text-xl text-gray-600">Encuentra el horario perfecto para tu actividad favorita</p>
          </div>

          <div className="max-w-4xl mx-auto">
            <Card>
              <CardHeader className="bg-sky-500 text-white">
                <CardTitle className="flex items-center space-x-2">
                  <Calendar className="h-5 w-5" />
                  <span>Cronograma Semanal</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Horario
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Lunes
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Martes
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Miércoles
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Jueves
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Viernes
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Sábado
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      <tr>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">16:00 - 17:00</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Fútbol 4-8 años</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Vóley Juvenil</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Fútbol 4-8 años</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Básquet 10-14</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Hockey Damas</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Fútbol 9-12</td>
                      </tr>
                      <tr>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">17:00 - 18:00</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Fútbol 9-12 años</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Básquet Adultos</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Fútbol 9-12 años</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Vóley Adultos</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Hockey Caballeros</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Fútbol 13-16</td>
                      </tr>
                      <tr>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">18:00 - 19:00</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Fútbol 13-16 años</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Hockey Juvenil</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Fútbol 13-16 años</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Básquet 15-18</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Vóley Mixto</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Torneos</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Instalaciones */}
      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Nuestras Instalaciones</h2>
            <p className="text-xl text-gray-600">Espacios modernos y seguros para la práctica deportiva</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="relative group overflow-hidden rounded-lg">
              <Image
                src="/placeholder.svg?height=300&width=400"
                alt="Cancha de fútbol principal"
                width={400}
                height={300}
                className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
              <div className="absolute bottom-4 left-4 text-white">
                <h3 className="text-lg font-semibold">Cancha de Fútbol Principal</h3>
                <p className="text-sm text-gray-200">Césped sintético de última generación</p>
              </div>
            </div>

            <div className="relative group overflow-hidden rounded-lg">
              <Image
                src="/placeholder.svg?height=300&width=400"
                alt="Cancha de básquet cubierta"
                width={400}
                height={300}
                className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
              <div className="absolute bottom-4 left-4 text-white">
                <h3 className="text-lg font-semibold">Cancha de Básquet</h3>
                <p className="text-sm text-gray-200">Cancha cubierta con piso profesional</p>
              </div>
            </div>

            <div className="relative group overflow-hidden rounded-lg">
              <Image
                src="/placeholder.svg?height=300&width=400"
                alt="Cancha de vóley"
                width={400}
                height={300}
                className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
              <div className="absolute bottom-4 left-4 text-white">
                <h3 className="text-lg font-semibold">Cancha de Vóley</h3>
                <p className="text-sm text-gray-200">Espacio amplio y bien iluminado</p>
              </div>
            </div>

            <div className="relative group overflow-hidden rounded-lg">
              <Image
                src="/placeholder.svg?height=300&width=400"
                alt="Cancha de hockey"
                width={400}
                height={300}
                className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
              <div className="absolute bottom-4 left-4 text-white">
                <h3 className="text-lg font-semibold">Cancha de Hockey</h3>
                <p className="text-sm text-gray-200">Césped natural mantenido profesionalmente</p>
              </div>
            </div>

            <div className="relative group overflow-hidden rounded-lg">
              <Image
                src="/placeholder.svg?height=300&width=400"
                alt="Vestuarios"
                width={400}
                height={300}
                className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
              <div className="absolute bottom-4 left-4 text-white">
                <h3 className="text-lg font-semibold">Vestuarios</h3>
                <p className="text-sm text-gray-200">Instalaciones modernas y limpias</p>
              </div>
            </div>

            <div className="relative group overflow-hidden rounded-lg">
              <Image
                src="/placeholder.svg?height=300&width=400"
                alt="Área de descanso"
                width={400}
                height={300}
                className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
              <div className="absolute bottom-4 left-4 text-white">
                <h3 className="text-lg font-semibold">Área de Descanso</h3>
                <p className="text-sm text-gray-200">Espacio para familias y espectadores</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonios */}
      <section className="py-16 lg:py-24 bg-sky-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Lo que dicen nuestros socios</h2>
            <p className="text-xl text-gray-600">Testimonios reales de nuestra comunidad deportiva</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-sky-200">
              <CardContent className="pt-6">
                <div className="flex items-center mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4">
                  "Mi hijo lleva 3 años en el club y ha crecido mucho como persona. Los profesores son excelentes y el
                  ambiente es muy familiar."
                </p>
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-sky-100 rounded-full flex items-center justify-center">
                    <span className="text-sky-600 font-semibold">MG</span>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">María González</p>
                    <p className="text-sm text-gray-500">Madre de socio - Fútbol Infantil</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-sky-200">
              <CardContent className="pt-6">
                <div className="flex items-center mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4">
                  "Encontré en el club no solo un lugar para hacer deporte, sino una segunda familia. Las instalaciones
                  son excelentes y el compañerismo es único."
                </p>
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-sky-100 rounded-full flex items-center justify-center">
                    <span className="text-sky-600 font-semibold">CR</span>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">Carlos Rodríguez</p>
                    <p className="text-sm text-gray-500">Socio - Básquet Adultos</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-sky-200">
              <CardContent className="pt-6">
                <div className="flex items-center mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4">
                  "El hockey femenino en Racing es increíble. Hemos logrado grandes resultados y sobre todo, hemos
                  formado un grupo muy unido."
                </p>
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-sky-100 rounded-full flex items-center justify-center">
                    <span className="text-sky-600 font-semibold">LS</span>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">Laura Sánchez</p>
                    <p className="text-sm text-gray-500">Socia - Hockey Damas</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Formulario de Contacto */}
      <section id="contacto" className="py-16 lg:py-24">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">¡Únete a Nuestra Familia Deportiva!</h2>
            <p className="text-xl text-gray-600">Completa el formulario y nos pondremos en contacto contigo</p>
          </div>

          <div className="max-w-2xl mx-auto">
            <Card>
              <CardHeader className="text-center">
                <CardTitle className="text-2xl text-sky-600">Formulario de Inscripción</CardTitle>
                <CardDescription>
                  Déjanos tus datos y te contactaremos para brindarte toda la información
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700">Nombre completo *</label>
                    <Input placeholder="Tu nombre completo" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700">Teléfono *</label>
                    <Input placeholder="Tu número de teléfono" />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Email *</label>
                  <Input type="email" placeholder="tu@email.com" />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Deporte de interés</label>
                  <select className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-500">
                    <option value="">Selecciona un deporte</option>
                    <option value="futbol">Fútbol Infantil</option>
                    <option value="basquet">Básquet</option>
                    <option value="voley">Vóley</option>
                    <option value="hockey">Hockey</option>
                    <option value="varios">Varios deportes</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Edad del participante</label>
                  <Input placeholder="Edad (si es para un menor)" />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Mensaje</label>
                  <Textarea
                    placeholder="Cuéntanos sobre tus intereses, experiencia previa o cualquier consulta que tengas..."
                    rows={4}
                  />
                </div>

                <Button className="w-full bg-sky-500 hover:bg-sky-600 text-white font-semibold py-3">
                  Enviar Solicitud
                </Button>

                <p className="text-sm text-gray-500 text-center">
                  * Campos obligatorios. Nos comprometemos a proteger tu privacidad.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-sky-500 rounded-full flex items-center justify-center">
                  <Trophy className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-bold">Club Atletico Racing</h3>
                  <p className="text-sm text-gray-400">Deporte y Comunidad</p>
                </div>
              </div>
              <p className="text-gray-400 text-sm">
                Más de 15 años formando campeones y construyendo comunidad a través del deporte.
              </p>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Deportes</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Fútbol Infantil
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Básquet
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Vóley
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Hockey
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Enlaces</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="#nosotros" className="hover:text-white transition-colors">
                    Sobre Nosotros
                  </Link>
                </li>
                <li>
                  <Link href="#horarios" className="hover:text-white transition-colors">
                    Horarios
                  </Link>
                </li>
                <li>
                  <Link href="#contacto" className="hover:text-white transition-colors">
                    Contacto
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Noticias
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Contacto</h4>
              <div className="space-y-3 text-gray-400">
                <div className="flex items-center space-x-3">
                  <MapPin className="h-4 w-4 text-sky-400" />
                  <span className="text-sm">Av. Deportes 1234, Ciudad</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Phone className="h-4 w-4 text-sky-400" />
                  <span className="text-sm">+54 11 1234-5678</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Mail className="h-4 w-4 text-sky-400" />
                  <span className="text-sm">info@clubracing.com</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Clock className="h-4 w-4 text-sky-400" />
                  <span className="text-sm">Lun-Sáb: 15:00-21:00</span>
                </div>
              </div>

              <div className="mt-6">
                <h5 className="text-sm font-semibold mb-3">Síguenos</h5>
                <div className="flex space-x-3">
                  <Link
                    href="#"
                    className="w-8 h-8 bg-sky-600 rounded-full flex items-center justify-center hover:bg-sky-700 transition-colors"
                  >
                    <Facebook className="h-4 w-4" />
                  </Link>
                  <Link
                    href="#"
                    className="w-8 h-8 bg-sky-600 rounded-full flex items-center justify-center hover:bg-sky-700 transition-colors"
                  >
                    <Instagram className="h-4 w-4" />
                  </Link>
                  <Link
                    href="#"
                    className="w-8 h-8 bg-sky-600 rounded-full flex items-center justify-center hover:bg-sky-700 transition-colors"
                  >
                    <Twitter className="h-4 w-4" />
                  </Link>
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} Club Atletico Racing. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
